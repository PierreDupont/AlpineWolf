mode <- function(x) {
  d <- density(x)
  d$x[which.max(d$y)]
}

library(coda)
library(rstan)
nimSummary = function(d = NULL, trace=FALSE, exclude.params = NULL, digits=2){
  if(is.null(exclude.params)==FALSE){
    require(stringr)
    tmp1 = ifelse(is.na(as.numeric(str_extract(attributes(d[[1]])$dimnames[[2]],"[1-9]+"))),attributes(d[[1]])$dimnames[[2]],substr(attributes(d[[1]])$dimnames[[2]],1,as.numeric(str_locate(attributes(d[[1]])$dimnames[[2]], "\\[")[, 1])-1))
    d.remove = lapply(d, function(x) which(tmp1 %in% exclude.params))
    d2 = lapply(d, function(x) x[,-d.remove[[1]]])
  }else
    if(is.null(exclude.params)){
      d2 = d
      d.remove = list()
      d.remove = 0
    }
  if((length(attributes(d[[1]])$dimnames[[2]])-length(d.remove[[1]])==1)){
    d3 = as.data.frame(do.call(c, d2))
    #d3 = d3[,-which(apply(d3, 2, function(x) any(x=="Inf")))]
    Means = mean(d3[,1], na.rm=TRUE)
    Mode= mode(d3[,1])
    Median= median(d3[,1], na.rm=TRUE)
    SDs = sd(d3[,1], na.rm=TRUE)
    q2.5 = quantile(d3[,1], 0.025, na.rm=TRUE)
    q50 = quantile(d3[,1], 0.50, na.rm=TRUE)
    q97.5 = quantile(d3[,1], 0.975, na.rm=TRUE)
    over.zero = round(mean(d3[,1]>0),2)
    n.eff = effectiveSize(mcmc.list(lapply(d2, as.mcmc)))
    Rhat = round(gelman.diag(mcmc.list(lapply(d2, as.mcmc)), multivariate = FALSE)[[1]][,1],3)
  }else
    if((length(attributes(d[[1]])$dimnames[[2]])-length(d.remove[[1]])>1)){
      d3=do.call(rbind,d2)
      #d3 = d3[,-which(apply(d3, 2, function(x) any(x=="Inf")))]
      Means = apply(d3, 2,function(x) mean(x,na.rm=TRUE))
      Mode = apply(d3, 2,function(x) mode(x))
      Median= apply(d3, 2,function(x) median(x,na.rm=TRUE))
      SDs = apply(d3, 2,function(x) sd(x,na.rm=TRUE))
      q2.5 = apply(d3, 2,function(x) quantile(x, 0.025,na.rm=TRUE))
      q50 = apply(d3, 2,function(x) quantile(x, 0.50,na.rm=TRUE))
      q97.5 = apply(d3, 2,function(x) quantile(x, 0.975,na.rm=TRUE))
      over.zero = round(apply(d3, 2, function(x) mean(x>0,na.rm=TRUE)),2)
      n.eff = effectiveSize(mcmc.list(lapply(d2, as.mcmc)))
      Rhat = round(gelman.diag(mcmc.list(lapply(d2, as.mcmc)), multivariate = FALSE)[[1]][,1],3)
      niter = attributes(d[[1]])$dim[1]
      param = attributes(d[[1]])$dim[2]
      arr<-array(0,c(niter,param,3))
      arr[,,1] <- as.matrix(outNim[[1]])
      arr[,,2] <- as.matrix(outNim[[2]])
      arr[,,3] <- as.matrix(outNim[[3]])
      #convert array to iterations x chains x parameters
      arr <- aperm(arr, c(1,3,2))
      #Calculate split-chain Rhat and other parameters
      #no warmup/burn-in iterations saved by nimble, so set warmup to 0
      mo=rstan::monitor(arr, warmup=0, print=FALSE)
    }
  if(trace==TRUE  & (length(attributes(d[[1]])$dimnames[[2]])-length(d.remove[[1]])>1)){
    par(mfrow=c(ncol(d3),2))
    for(i in 1:ncol(d3)){
      plot(1:dim(d2[[1]])[1],d2[[1]][,i],xlab="iteration",ylab=colnames(d3)[i],type="l",ylim=range(do.call(rbind, lapply(d2,function(x) apply(x, 2, range)))[,i]))
      for(j in 2:length(d2)){
        lines(1:dim(d2[[1]])[1],d2[[j]][,i],xlab="iteration",ylab=colnames(d3)[i],type="l",col="red")
      }
      hist(d3[,i],main="",xlab=colnames(d3)[i])
    }
  }else
    if(trace==TRUE  & (length(attributes(d[[1]])$dimnames[[2]])-length(d.remove[[1]])==1)){
      par(mfrow=c(1,2))
      plot(1:length(d2[[1]]),d2[[1]],xlab="iteration",ylab=colnames(d3)[i],type="l",ylim=range(d3[,1]))
      for(j in 2:length(d2)){
        lines(1:length(d2[[j]]),d2[[j]],xlab="iteration",ylab=colnames(d3)[i],type="l",col="red")
      }
      hist(d3[,1],main="",xlab=attributes(d[[1]])$dimnames[[2]][-d.remove[[1]]])
    }
  tmp.frame = data.frame(Mean=Means,Mode=Mode,SD=SDs,q2.5=q2.5,q50=q50,q97.5=q97.5,f0=over.zero,n.eff=n.eff,Bulk_ESS=mo$Bulk_ESS,Tail_ESS=mo$Tail_ESS, Rhat=mo$Rhat)
  if(nrow(tmp.frame)==1){
    row.names(tmp.frame) = attributes(d[[1]])$dimnames[[2]][-d.remove[[1]]]
  }
  return(paste(cat("For each parameter, Bulk_ESS and Tail_ESS are crude measures of effective \nsample size for bulk and tail quantities respectively (an ESS > 100 per chain \nis considered good), and Rhat is the potential scale reduction factor on rank \nnormalized split chains (at convergence, Rhat <= 1.05).\n\n"), return(round(tmp.frame, digits=digits))))
}

